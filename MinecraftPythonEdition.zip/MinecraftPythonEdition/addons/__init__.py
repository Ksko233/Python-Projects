"""为Minecaft添加Mod, 一次只能使用一个Mod"""
#可用Mod:迷宫地图,简化世界
